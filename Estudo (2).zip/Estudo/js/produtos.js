
const CATALOGO_PRODUTOS = [
  {
    id: 1,
    nome: "Suco de Laranja Fresco 500ml",
    categoria: "Cítricos",
    descricao: "Espremido na hora com laranjas selecionadas e sem adição de conservantes.",
    preco: 9.50,
    imagem: "Img/suco_laranja.jpg"
  },
  {
    id: 2,
    nome: "Suco de Maracujá Cremoso 500ml",
    categoria: "Tropicais",
    descricao: "Feito com polpa natural da fruta, refrescante e aromático.",
    preco: 11.00,
    imagem: "Img/suco_maracuja.jpg"
  },
  {
    id: 3,
    nome: "Suco de Uva Integral 500ml",
    categoria: "Especiais",
    descricao: "Encorpado e 100% fruta, ideal para acompanhar suas refeições.",
    preco: 12.00,
    imagem: "Img/suco_uva.jpg"
  }
];

function addToCart(productId) {
  const produto = CATALOGO_PRODUTOS.find((p) => p.id === Number(productId));
  if (!produto) return;

  const cart = getCart();
  const existing = cart.find((item) => item.id === produto.id);

  if (existing) {
    existing.quantidade += 1;
  } else {
    cart.push({
      id: produto.id,
      nome: produto.nome,
      preco: produto.preco,
      imagem: produto.imagem,
      quantidade: 1
    });
  }

  saveCart(cart);
  showToast(`"${produto.nome}" adicionado ao carrinho!`);
}

function renderProducts(filterText = "") {
  const container = document.getElementById("productsContainer");
  if (!container) return;

  const query = filterText.trim().toLowerCase();
  const filtered = CATALOGO_PRODUTOS.filter(
    (p) =>
      p.nome.toLowerCase().includes(query) ||
      p.categoria.toLowerCase().includes(query) ||
      p.descricao.toLowerCase().includes(query)
  );

  if (filtered.length === 0) {
    container.innerHTML = `<p class="empty-state">Nenhum suco encontrado para "${filterText}".</p>`;
    return;
  }

  container.innerHTML = filtered
    .map(
      (prod) => `
      <article class="card">
        <img src="${prod.imagem}" alt="${prod.nome}" class="card-img" onerror="this.src='Img/logo.jpg'">
        <div class="card-body">
          <span class="card-meta">${prod.categoria}</span>
          <h3 class="card-title">${prod.nome}</h3>
          <p class="card-desc">${prod.descricao}</p>
          <div class="card-footer">
            <span class="price">${formatBRL(prod.preco)}</span>
            <button type="button" class="btn btn-primary btn-sm" data-add-id="${prod.id}">
              Adicionar
            </button>
          </div>
        </div>
      </article>
    `
    )
    .join("");

  container.querySelectorAll("[data-add-id]").forEach((btn) => {
    btn.addEventListener("click", () => addToCart(btn.getAttribute("data-add-id")));
  });
}

document.addEventListener("DOMContentLoaded", () => {
  renderProducts();
  const searchInput = document.getElementById("searchProduct");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => renderProducts(e.target.value));
  }
});