
const CART_STORAGE_KEY = "fp_cart_v1";
const SESSION_STORAGE_KEY = "fp_session_v1";

function formatBRL(value) {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
}

function getCart() {
  try {
    const raw = localStorage.getItem(CART_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  updateCartBadge();
}

function getSessionUser() {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    return raw ? JSON.parse(raw) : { nome: "Cliente Primavera", email: "cliente@frutariaprimavera.com.br", perfil: "Cliente" };
  } catch {
    return { nome: "Visitante", email: "visitante@frutariaprimavera.com.br", perfil: "Cliente" };
  }
}

function saveSessionUser(user) {
  localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
}

function showToast(message) {
  let toast = document.getElementById("fpToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "fpToast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2400);
}

function updateCartBadge() {
  const badges = document.querySelectorAll("[data-cart-badge]");
  const cart = getCart();
  const totalItems = cart.reduce((acc, item) => acc + item.quantidade, 0);
  badges.forEach((el) => {
    el.textContent = totalItems;
  });
}

function highlightActiveNav() {
  const currentPage = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach((link) => {
    const href = link.getAttribute("href");
    if (href === currentPage) {
      link.classList.add("active");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  highlightActiveNav();
  updateCartBadge();
});