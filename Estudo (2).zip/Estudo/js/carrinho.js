
function changeItemQty(productId, delta) {
  const cart = getCart();
  const idx = cart.findIndex((item) => item.id === Number(productId));
  if (idx === -1) return;

  cart[idx].quantidade += delta;
  if (cart[idx].quantidade <= 0) {
    cart.splice(idx, 1);
  }
  saveCart(cart);
  renderCartPage();
}

function removeCartItem(productId) {
  const cart = getCart().filter((item) => item.id !== Number(productId));
  saveCart(cart);
  renderCartPage();
  showToast("Suco removido do carrinho.");
}

function clearCart() {
  saveCart([]);
  renderCartPage();
  showToast("Carrinho esvaziado.");
}

function renderCartPage() {
  const listEl = document.getElementById("cartItemsList");
  const subtotalEl = document.getElementById("cartSubtotal");
  const totalEl = document.getElementById("cartTotal");
  const checkoutBtn = document.getElementById("checkoutBtn");

  if (!listEl || !subtotalEl || !totalEl) return;

  const cart = getCart();

  if (cart.length === 0) {
    listEl.innerHTML = `
      <div class="empty-state">
        <p>Seu carrinho da Frutaria Primavera está vazio.</p>
        <br>
        <a href="index.html" class="btn btn-primary btn-sm">Escolher sucos</a>
      </div>
    `;
    subtotalEl.textContent = formatBRL(0);
    totalEl.textContent = formatBRL(0);
    if (checkoutBtn) checkoutBtn.disabled = true;
    return;
  }

  if (checkoutBtn) checkoutBtn.disabled = false;

  listEl.innerHTML = cart
    .map(
      (item) => `
      <div class="cart-item">
        <div class="cart-item-info">
          <h3>${item.nome}</h3>
          <p>${formatBRL(item.preco)} cada • Subtotal: <strong>${formatBRL(item.preco * item.quantidade)}</strong></p>
        </div>
        <div class="cart-controls">
          <button type="button" class="btn btn-outline btn-sm" data-dec="${item.id}">-</button>
          <span class="qty-value">${item.quantidade}</span>
          <button type="button" class="btn btn-outline btn-sm" data-inc="${item.id}">+</button>
          <button type="button" class="btn btn-danger btn-sm" data-del="${item.id}">Remover</button>
        </div>
      </div>
    `
    )
    .join("");

  const subtotal = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  subtotalEl.textContent = formatBRL(subtotal);
  totalEl.textContent = formatBRL(subtotal);

  listEl.querySelectorAll("[data-dec]").forEach((btn) =>
    btn.addEventListener("click", () => changeItemQty(btn.getAttribute("data-dec"), -1))
  );
  listEl.querySelectorAll("[data-inc]").forEach((btn) =>
    btn.addEventListener("click", () => changeItemQty(btn.getAttribute("data-inc"), 1))
  );
  listEl.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => removeCartItem(btn.getAttribute("data-del")))
  );
}

document.addEventListener("DOMContentLoaded", () => {
  renderCartPage();

  const clearBtn = document.getElementById("clearCartBtn");
  if (clearBtn) clearBtn.addEventListener("click", clearCart);

  const checkoutBtn = document.getElementById("checkoutBtn");
  const feedback = document.getElementById("cartFeedback");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      const cart = getCart();
      if (cart.length === 0) return;

      const pedidosSalvos = JSON.parse(localStorage.getItem("fp_orders_v1") || "[]");
      const total = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
      const user = getSessionUser();

      pedidosSalvos.unshift({
        id: "PED-" + Math.floor(1000 + Math.random() * 9000),
        cliente: user.nome,
        itens: cart.reduce((s, i) => s + i.quantidade, 0),
        total,
        status: "Confirmado"
      });
      localStorage.setItem("fp_orders_v1", JSON.stringify(pedidosSalvos));

      saveCart([]);
      renderCartPage();
      if (feedback) {
        feedback.className = "feedback-msg success";
        feedback.textContent = `Pedido confirmado na Frutaria Primavera (${formatBRL(total)}). Veja no Dashboard!`;
      }
    });
  }
});