
function setFeedback(el, type, message) {
  if (!el) return;
  el.className = `feedback-msg ${type}`;
  el.textContent = message;
}

document.addEventListener("DOMContentLoaded", () => {
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const nome = document.getElementById("nome")?.value.trim() || "";
      const email = document.getElementById("email")?.value.trim() || "";
      const assunto = document.getElementById("assunto")?.value.trim() || "";
      const mensagem = document.getElementById("mensagem")?.value.trim() || "";
      const feedback = document.getElementById("contactFeedback");

      if (nome.length < 2 || !email.includes("@") || mensagem.length < 5) {
        setFeedback(feedback, "error", "Preencha nome, um e-mail válido e uma mensagem com pelo menos 5 caracteres.");
        return;
      }

      const mensagens = JSON.parse(localStorage.getItem("fp_contacts_v1") || "[]");
      mensagens.unshift({ nome, email, assunto: assunto || "Atendimento", mensagem, data: new Date().toLocaleDateString("pt-BR") });
      localStorage.setItem("fp_contacts_v1", JSON.stringify(mensagens));

      contactForm.reset();
      setFeedback(feedback, "success", "Mensagem enviada para a Frutaria Primavera! Retornaremos em breve.");
    });
  }

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("loginEmail")?.value.trim() || "";
      const senha = document.getElementById("loginSenha")?.value.trim() || "";
      const feedback = document.getElementById("loginFeedback");

      if (!email.includes("@") || senha.length < 4) {
        setFeedback(feedback, "error", "Informe um e-mail válido e uma senha com pelo menos 4 caracteres.");
        return;
      }

      const nomeDerivado = email.split("@")[0].replace(/[._]/g, " ");
      saveSessionUser({
        nome: nomeDerivado.charAt(0).toUpperCase() + nomeDerivado.slice(1),
        email,
        perfil: "Cliente Autenticado"
      });

      setFeedback(feedback, "success", `Bem-vindo à Frutaria Primavera, ${email}!`);
    });
  }

  const profileForm = document.getElementById("profileForm");
  if (profileForm) {
    const session = getSessionUser();
    const nomeInput = document.getElementById("perfilNome");
    const emailInput = document.getElementById("perfilEmail");
    const bioInput = document.getElementById("perfilBio");

    if (nomeInput) nomeInput.value = session.nome || "";
    if (emailInput) emailInput.value = session.email || "";
    if (bioInput) bioInput.value = session.bio || "Apreciador de sucos naturais feitos na hora.";

    profileForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const feedback = document.getElementById("profileFeedback");
      const updated = {
        ...session,
        nome: nomeInput?.value.trim() || session.nome,
        email: emailInput?.value.trim() || session.email,
        bio: bioInput?.value.trim() || ""
      };
      saveSessionUser(updated);
      setFeedback(feedback, "success", "Dados do perfil atualizados com sucesso!");
    });
  }
});