CREATE DATABASE IF NOT EXISTS frutaria_primavera_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE frutaria_primavera_db;


CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  perfil ENUM('cliente', 'admin') DEFAULT 'cliente',
  ativo TINYINT(1) DEFAULT 1,
  ultimo_login TIMESTAMP NULL DEFAULT NULL,
  ultimo_logout TIMESTAMP NULL DEFAULT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS produtos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  categoria VARCHAR(60) NOT NULL,
  descricao TEXT,
  preco DECIMAL(10, 2) NOT NULL,
  estoque INT NOT NULL DEFAULT 0,
  imagem VARCHAR(160),
  ativo TINYINT(1) DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NULL,
  cliente_nome VARCHAR(120) NOT NULL,
  total DECIMAL(10, 2) NOT NULL,
  status ENUM('pendente', 'confirmado', 'entregue', 'cancelado') DEFAULT 'pendente',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE SET NULL ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS itens_pedido (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  produto_id INT NOT NULL,
  quantidade INT NOT NULL,
  preco_unitario DECIMAL(10, 2) NOT NULL,
  CONSTRAINT fk_itens_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_itens_produto FOREIGN KEY (produto_id) REFERENCES produtos(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS contatos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL,
  assunto VARCHAR(140) NOT NULL,
  mensagem TEXT NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES
  ('Administrador Primavera', 'admin@frutariaprimavera.com.br', 'hash_demo_123', 'admin'),
  ('Cliente Primavera', 'cliente@frutariaprimavera.com.br', 'hash_demo_456', 'cliente')
ON DUPLICATE KEY UPDATE nome = VALUES(nome);


INSERT INTO produtos (nome, categoria, descricao, preco, estoque, imagem) VALUES
  ('Suco de Laranja Fresco 500ml', 'Cítricos', 'Espremido na hora com laranjas selecionadas e sem conservantes.', 9.50, 40, 'img/suco_laranja.jpg'),
  ('Suco de Maracujá Cremoso 500ml', 'Tropicais', 'Polpa natural batida na hora com equilíbrio perfeito de acidez.', 11.00, 30, 'img/suco_maracuja.jpg'),
  ('Suco de Uva Integral 500ml', 'Especiais', 'Sabor intenso e natural, rico em antioxidantes.', 12.00, 25, 'img/suco_uva.jpg');

INSERT INTO pedidos (usuario_id, cliente_nome, total, status) VALUES
  (1, 'Administrador Primavera', 20.50, 'entregue'),
  (2, 'Cliente Primavera', 12.00, 'confirmado');

INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario) VALUES
  (1, 1, 1, 9.50),
  (1, 2, 1, 11.00),
  (2, 3, 1, 12.00);